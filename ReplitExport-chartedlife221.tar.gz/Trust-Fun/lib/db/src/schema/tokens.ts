import {
  pgTable,
  text,
  serial,
  timestamp,
  boolean,
  real,
  integer,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const tokenStatusEnum = pgEnum("token_status", [
  "live",
  "upcoming",
  "ended",
]);

export const tokensTable = pgTable("tokens", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  contractAddress: text("contract_address"),
  creatorWallet: text("creator_wallet").notNull(),
  totalSupply: real("total_supply").notNull(),
  price: real("price").notNull().default(0),
  marketCap: real("market_cap").notNull().default(0),
  volume24h: real("volume_24h").notNull().default(0),
  liquidityAmount: real("liquidity_amount").notNull().default(0),
  liquidityLocked: boolean("liquidity_locked").notNull().default(false),
  liquidityLockDays: integer("liquidity_lock_days").notNull().default(0),
  mintAuthorityRevoked: boolean("mint_authority_revoked").notNull().default(false),
  freezeAuthorityRevoked: boolean("freeze_authority_revoked").notNull().default(false),
  contractVerified: boolean("contract_verified").notNull().default(false),
  teamWalletPercent: real("team_wallet_percent").notNull().default(0),
  safetyScore: integer("safety_score").notNull().default(0),
  status: tokenStatusEnum("status").notNull().default("upcoming"),
  category: text("category").notNull().default("meme"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertTokenSchema = createInsertSchema(tokensTable).omit({
  id: true,
  price: true,
  marketCap: true,
  volume24h: true,
  contractVerified: true,
  safetyScore: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertToken = z.infer<typeof insertTokenSchema>;
export type Token = typeof tokensTable.$inferSelect;
