import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { tokensTable } from "./tokens";

export const commentsTable = pgTable("comments", {
  id: serial("id").primaryKey(),
  tokenId: integer("token_id")
    .notNull()
    .references(() => tokensTable.id, { onDelete: "cascade" }),
  message: text("message").notNull(),
  walletAddress: text("wallet_address").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCommentSchema = createInsertSchema(commentsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof commentsTable.$inferSelect;
